package com.example.asynctask.model;

import android.graphics.Bitmap;

import com.google.gson.annotations.SerializedName;

public class Planet {
    @SerializedName("name")
    private String nameOfPlanet;

    @SerializedName("distance")
    private int distance;

    @SerializedName("gravity")
    private int gravity;

    @SerializedName("diameter")
    private int diameter;

    @SerializedName("image")
    private String image;

    private Bitmap bmpImage;

    public void setBmpImage(Bitmap bmpImage) {
        this.bmpImage = bmpImage;
    }

    public Bitmap getBmpImage() {
        return bmpImage;
    }

    public String getName() {
        return nameOfPlanet;
    }

    public void setName(String name) {
        this.nameOfPlanet = name;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getGravity() {
        return gravity;
    }

    public void setGravity(int gravity) {
        this.gravity = gravity;
    }

    public int getDiameter() {
        return diameter;
    }

    public void setDiameter(int diameter) {
        this.diameter = diameter;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
