package com.example.asynctask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.asynctask.model.Planet;
import com.example.asynctask.model.PlanetListAdapter;
import com.example.asynctask.tasks.DownloadPlanetThread;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public void prepareUIStartDownload(){
        Button btnDownload = findViewById(R.id.btn_download);
        btnDownload.setEnabled(false);
        ProgressBar pb = findViewById(R.id.progressBar);
        pb.setVisibility(View.VISIBLE);
    }

    public void prepareUIFinishDownload(List<Planet> results){
        Button btnDownload = findViewById(R.id.btn_download);
        btnDownload.setEnabled(true);
        ProgressBar pb = findViewById(R.id.progressBar);
        TextView label = findViewById(R.id.lbl_show);
        label.setText(results.toString());
        pb.setVisibility(View.INVISIBLE);

        ListView lv = findViewById(R.id.lst_planets);
        ((PlanetListAdapter) lv.getAdapter()).addAll(results);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnDownload = findViewById(R.id.btn_download);

        PlanetListAdapter planetListAdapter = new PlanetListAdapter(new LinkedList<Planet>());
        ((ListView)findViewById(R.id.lst_planets)).setAdapter(planetListAdapter);

        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                URL wsUrl = null;
                try {
                    wsUrl = new URL("http://sanger.dia.fi.upm.es/pmd-task/public/list-example/planets.php");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

                DownloadPlanetThread dTask = new DownloadPlanetThread(MainActivity.this, wsUrl);
                dTask.run();
            }
        });


    }
}