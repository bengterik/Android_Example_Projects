package com.example.asynctask.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.asynctask.R;

import java.util.List;

public class PlanetListAdapter extends BaseAdapter {
    private List<Planet> data;

    public PlanetListAdapter(List<Planet> planets) {
        data.addAll(planets);
    }

    public void addAll(List<Planet> planets) {
        data.clear();
        data.addAll(planets);

    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) view.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (view == null) {
            view = inflater.inflate(R.layout.planet_row_layout, null);
        }

        TextView nameField = view.findViewById(R.id.txt_row_name);
        nameField.setText(data.get(i).getName());
        TextView diameterField = view.findViewById(R.id.txt_row_diameter);
        diameterField.setText(data.get(i).getName()+"");

        ImageView imageView = view.findViewById(R.id.image_planet);
        imageView.setImageBitmap(data.get(i).getBmpImage());

        return view;
    }
}
