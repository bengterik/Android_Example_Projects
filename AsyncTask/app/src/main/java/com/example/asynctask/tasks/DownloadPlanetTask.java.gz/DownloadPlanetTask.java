package com.example.asynctask.tasks;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import com.example.asynctask.MainActivity;
import com.example.asynctask.NetUtil;
import com.example.asynctask.model.Planet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.net.URL;
import java.util.Arrays;
import java.util.List;

public class DownloadPlanetTask extends AsyncTask<URL, Void, List<Planet>> {
    private Context ctx;
    private ProgressDialog progressDialog;


    public DownloadPlanetTask(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected List<Planet> doInBackground(URL... urls) {
        String content = NetUtil.getTextFromURL(urls[0]);
        GsonBuilder gsb = new GsonBuilder();
        Gson gson = gsb.create();
        List<Planet> resultPlanets = Arrays.asList(gson.fromJson(content, Planet[].class));

        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultPlanets;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        ((MainActivity)ctx).prepareUIStartDownload();
        ProgressDialog progressDialog = new ProgressDialog(ctx);
        progressDialog.setMessage("Doing something ...");
        progressDialog.setCancelable(false);
        progressDialog.show();

    }

    @Override
    protected void onPostExecute(List<Planet> s) {
        super.onPostExecute(s);
        progressDialog.dismiss();
    }
}
