package com.example.asynctask.tasks;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.example.asynctask.MainActivity;
import com.example.asynctask.NetUtil;
import com.example.asynctask.model.Planet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.net.URL;
import java.util.Arrays;
import java.util.List;

public class DownloadPlanetThread implements Runnable {
    private Context ctx;
    private URL[] urls;

    public DownloadPlanetThread(Context ctx, URL... urls) {
        this.ctx = ctx;
        this.urls = urls;
    }

    @Override
    public void run() {
        ((MainActivity)ctx).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((MainActivity)ctx).prepareUIStartDownload();
            }
        });

        String result = NetUtil.getTextFromURL(urls[0]);

        String imageBaseURL = "";

        GsonBuilder gsb = new GsonBuilder();
        Gson gson = gsb.create();

        List<Planet> resultPlanets = Arrays.asList(gson.fromJson(result, Planet[].class));

        for (Planet p : resultPlanets) {
            Bitmap bmpPlanet = null;
            try {
                bmpPlanet = NetUtil.readBitmapUrl(new URL(imageBaseURL + p.getImage()));
            } catch (Exception e) {
                e.printStackTrace();
            }
            p.setBmpImage(bmpPlanet);
        }

        try{
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ((MainActivity)ctx).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((MainActivity)ctx).prepareUIFinishDownload(resultPlanets);
            }
        });

    }
}
